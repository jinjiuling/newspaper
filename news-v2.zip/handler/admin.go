package handler

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/arussellsaw/news/dao"
	"github.com/arussellsaw/news/domain"
)

// Session management
var sessions = make(map[string]time.Time)

func getSessionToken() string {
	return fmt.Sprintf("%x", time.Now().UnixNano())
}

func createSession(w http.ResponseWriter) {
	token := getSessionToken()
	sessions[token] = time.Now().Add(24 * time.Hour)
	http.SetCookie(w, &http.Cookie{
		Name:     "admin_session",
		Value:    token,
		Path:     "/",
		MaxAge:   86400,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
}

func isValidSession(r *http.Request) bool {
	cookie, err := r.Cookie("admin_session")
	if err != nil {
		return false
	}
	expiry, ok := sessions[cookie.Value]
	if !ok {
		return false
	}
	if time.Now().After(expiry) {
		delete(sessions, cookie.Value)
		return false
	}
	return true
}

func requireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !isValidSession(r) {
			http.Redirect(w, r, "/admin/login", http.StatusFound)
			return
		}
		next(w, r)
	}
}

func checkPassword(password string) bool {
	expected := os.Getenv("ADMIN_PASSWORD")
	if expected == "" {
		expected = "admin123"
	}
	h1 := sha256.Sum256([]byte(password))
	h2 := sha256.Sum256([]byte(expected))
	return hex.EncodeToString(h1[:]) == hex.EncodeToString(h2[:])
}

// ===== Login/Logout =====

func handleAdminLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		t, _ := template.ParseFiles("tmpl/admin_login.html")
		t.Execute(w, nil)
		return
	}

	r.ParseForm()
	password := r.FormValue("password")
	if !checkPassword(password) {
		t, _ := template.ParseFiles("tmpl/admin_login.html")
		t.Execute(w, map[string]string{"Error": "密码错误"})
		return
	}

	createSession(w)
	http.Redirect(w, r, "/admin/", http.StatusFound)
}

func handleAdminLogout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("admin_session")
	if err == nil {
		delete(sessions, cookie.Value)
	}
	http.SetCookie(w, &http.Cookie{
		Name:   "admin_session",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	})
	http.Redirect(w, r, "/admin/login", http.StatusFound)
}

// ===== Dashboard =====

func handleAdminDashboard(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	sources, _ := dao.GetAllSources(ctx)
	articleCount := 0
	db := dao.GetDB()
	if db != nil {
		db.QueryRow("SELECT COUNT(*) FROM articles").Scan(&articleCount)
	}

	data := struct {
		Sources      []domain.Source
		ArticleCount int
		CurrentTime  string
	}{
		Sources:      sources,
		ArticleCount: articleCount,
		CurrentTime:  time.Now().Format("2006-01-02 15:04:05"),
	}

	t, err := template.ParseFiles("tmpl/admin_dashboard.html")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	t.Execute(w, data)
}

// ===== Source Management =====

func handleAdminSources(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	sources, _ := dao.GetAllSources(ctx)

	t, err := template.ParseFiles("tmpl/admin_sources.html")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	t.Execute(w, sources)
}

func handleAdminSourceAdd(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		t, _ := template.ParseFiles("tmpl/admin_source_form.html")
		t.Execute(w, map[string]interface{}{"Action": "add"})
		return
	}

	r.ParseForm()
	enabled := r.FormValue("enabled") == "on"
	s := &domain.Source{
		Name:       r.FormValue("name"),
		URL:        r.FormValue("url"),
		FeedURL:    r.FormValue("feed_url"),
		Categories: []string{r.FormValue("category")},
		Enabled:    enabled,
	}

	ctx := r.Context()
	if err := dao.AddSource(ctx, s); err != nil {
		t, _ := template.ParseFiles("tmpl/admin_source_form.html")
		t.Execute(w, map[string]interface{}{"Action": "add", "Error": err.Error(), "Source": s})
		return
	}

	http.Redirect(w, r, "/admin/sources", http.StatusFound)
}

func handleAdminSourceEdit(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	if r.Method == "GET" {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		s, err := dao.GetSourceByID(ctx, id)
		if err != nil {
			http.Error(w, "Source not found", 404)
			return
		}
		t, _ := template.ParseFiles("tmpl/admin_source_form.html")
		t.Execute(w, map[string]interface{}{"Action": "edit", "Source": s})
		return
	}

	r.ParseForm()
	id, _ := strconv.Atoi(r.FormValue("id"))
	enabled := r.FormValue("enabled") == "on"
	s := &domain.Source{
		ID:         id,
		Name:       r.FormValue("name"),
		URL:        r.FormValue("url"),
		FeedURL:    r.FormValue("feed_url"),
		Categories: []string{r.FormValue("category")},
		Enabled:    enabled,
	}

	if err := dao.UpdateSource(ctx, s); err != nil {
		t, _ := template.ParseFiles("tmpl/admin_source_form.html")
		t.Execute(w, map[string]interface{}{"Action": "edit", "Error": err.Error(), "Source": s})
		return
	}

	http.Redirect(w, r, "/admin/sources", http.StatusFound)
}

func handleAdminSourceDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}

	r.ParseForm()
	id, _ := strconv.Atoi(r.FormValue("id"))
	ctx := r.Context()

	if err := dao.DeleteSource(ctx, id); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	http.Redirect(w, r, "/admin/sources", http.StatusFound)
}

func handleAdminSourceToggle(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}

	r.ParseForm()
	id, _ := strconv.Atoi(r.FormValue("id"))
	ctx := r.Context()

	s, err := dao.GetSourceByID(ctx, id)
	if err != nil {
		http.Error(w, "Source not found", 404)
		return
	}

	s.Enabled = !s.Enabled
	if err := dao.UpdateSource(ctx, s); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	http.Redirect(w, r, "/admin/sources", http.StatusFound)
}

// ===== Article Management =====

func handleAdminArticles(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	pageSize := 20

	sourceFilter := r.URL.Query().Get("source")

	articles, total, _ := dao.GetArticles(ctx, page, pageSize, sourceFilter)
	sourceNames, _ := dao.GetDistinctSourceNames(ctx)

	totalPages := (total + pageSize - 1) / pageSize

	data := struct {
		Articles     []domain.Article
		SourceNames  []string
		CurrentPage  int
		TotalPages   int
		Total        int
		SourceFilter string
	}{
		Articles:     articles,
		SourceNames:  sourceNames,
		CurrentPage:  page,
		TotalPages:   totalPages,
		Total:        total,
		SourceFilter: sourceFilter,
	}

	t, err := template.New("admin_articles.html").Funcs(TemplateFuncs).ParseFiles("tmpl/admin_articles.html")
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	t.Execute(w, data)
}

func handleAdminArticleDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}

	r.ParseForm()
	id := r.FormValue("id")
	ctx := r.Context()

	if err := dao.DeleteArticle(ctx, id); err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	redirect := r.FormValue("redirect")
	if redirect == "" {
		redirect = "/admin/articles"
	}
	http.Redirect(w, r, redirect, http.StatusFound)
}

func handleAdminDeleteBySource(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}

	r.ParseForm()
	sourceName := r.FormValue("source_name")
	ctx := r.Context()

	n, err := dao.DeleteArticlesBySource(ctx, sourceName)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	log.Printf("Deleted %d articles from source: %s", n, sourceName)
	http.Redirect(w, r, "/admin/articles", http.StatusFound)
}

// ===== Poll =====

func handleAdminPoll(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}

	ctx := r.Context()
	sources, err := dao.GetSources(ctx)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	go pollAllSources(ctx, sources)

	http.Redirect(w, r, "/admin/", http.StatusFound)
}
