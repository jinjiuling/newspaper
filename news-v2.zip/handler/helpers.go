package handler

import (
	"html/template"
	"os"
)

// TemplateFuncs returns custom template functions
var TemplateFuncs = template.FuncMap{
	"minus": func(a, b int) int { return a - b },
	"plus":  func(a, b int) int { return a + b },
    "safeHTML": func(s string) template.HTML { return template.HTML(s) },
}

func getAdminPassword() string {
	p := os.Getenv("ADMIN_PASSWORD")
	if p == "" {
		return "admin123"
	}
	return p
}
