package handler

import (
	"context"
	"net/http"
	"net/http/cookiejar"
)

var (
	jar, _ = cookiejar.New(&cookiejar.Options{})
	c      = http.Client{
		Jar: jar,
	}
)

func Init(ctx context.Context) http.Handler {
	m := http.NewServeMux()

	// Static files
	m.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static/"))))

	// Public pages
	m.HandleFunc("/article", handleArticle)
	m.HandleFunc("/image", handleDitherImage)
	m.HandleFunc("/favicon.ico", func(w http.ResponseWriter, r *http.Request) {
		http.NotFound(w, r)
	})
	m.HandleFunc("/barcode", handleQRCode)
	m.HandleFunc("/generate-edition", handleGenerateEdition)
	m.HandleFunc("/poll", handlePoll)
	m.HandleFunc("/", handleNews)

	// Admin routes
	m.HandleFunc("/admin/login", handleAdminLogin)
	m.HandleFunc("/admin/logout", handleAdminLogout)
	m.HandleFunc("/admin/sources", requireAuth(handleAdminSources))
	m.HandleFunc("/admin/sources/add", requireAuth(handleAdminSourceAdd))
	m.HandleFunc("/admin/sources/edit", requireAuth(handleAdminSourceEdit))
	m.HandleFunc("/admin/sources/delete", requireAuth(handleAdminSourceDelete))
	m.HandleFunc("/admin/sources/toggle", requireAuth(handleAdminSourceToggle))
	m.HandleFunc("/admin/articles", requireAuth(handleAdminArticles))
	m.HandleFunc("/admin/articles/delete", requireAuth(handleAdminArticleDelete))
	m.HandleFunc("/admin/articles/delete-source", requireAuth(handleAdminDeleteBySource))
	m.HandleFunc("/admin/poll", requireAuth(handleAdminPoll))
	m.HandleFunc("/admin/", requireAuth(handleAdminDashboard))

	return m
}
