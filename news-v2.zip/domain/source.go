package domain

type Source struct {
	ID           int
	Name         string
	URL          string
	FeedURL      string
	Categories   []string
	ForceFetch   bool
	DisableFetch bool
	Enabled      bool
}
