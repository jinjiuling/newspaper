module github.com/arussellsaw/news

go 1.22

require (
	github.com/PuerkitoBio/goquery v1.9.2
	github.com/boombuler/barcode v1.0.1
	github.com/bwmarrin/snowflake v0.3.0
	github.com/esimov/dithergo v0.0.0-20190411040508-1672f44e9674
	github.com/mmcdole/gofeed v1.3.0
	github.com/nfnt/resize v0.0.0-20180221191011-83c6a9932646
	modernc.org/sqlite v1.29.6
)