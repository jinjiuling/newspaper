package domain

import (
	"context"
	"time"

	"github.com/arussellsaw/news/idgen"
)

var (
	morningEdition time.Duration = 6 * time.Hour
	eveningEdition time.Duration = 17 * time.Hour
)

type Edition struct {
	ID         string
	Name       string
	Sources    []Source
	Articles   []Article
	Categories []string
	Date       string

	StartTime time.Time
	EndTime   time.Time
	Created   time.Time

	Metadata map[string]string

// SectionNames is the list of section template names to render (computed dynamically)
	SectionNames []string

	Article    Article
	claimed    map[string]bool
	sizeIndex  map[int][]int
}

func (e *Edition) ComputeSections() {
	count := len(e.Articles) / 6
	if count < 1 {
		count = 1
	}
	if count > 12 {
		count = 12
	}
	pattern := []string{
		"section-1", "section-2", "section-3", "section-4",
		"section-5", "section-6", "section-6", "section-7",
		"section-3", "section-8", "section-2",
	}
	e.SectionNames = make([]string, 0, count*len(pattern))
	for i := 0; i < count; i++ {
		e.SectionNames = append(e.SectionNames, pattern...)
	}

	e.buildSizeIndex()
}

func (e *Edition) buildSizeIndex() {
	e.sizeIndex = make(map[int][]int)
	for i, a := range e.Articles {
		if a.ID == "bar" {
			continue
		}
		size := a.Size()
		roundDown := (size / 100) * 100
		for s := roundDown; s >= 0; s -= 100 {
			e.sizeIndex[s] = append(e.sizeIndex[s], i)
		}
	}
}

func (e *Edition) GetArticle(size int, image bool) Article {
	if e.claimed == nil {
		e.claimed = make(map[string]bool)
	}
	if e.sizeIndex == nil {
		e.buildSizeIndex()
	}

	roundDown := (size / 100) * 100
	for _, idx := range e.sizeIndex[roundDown] {
		a := &e.Articles[idx]
		if e.claimed[a.ID] {
			continue
		}
		if a.ImageURL == "" && image {
			continue
		}
		e.claimed[a.ID] = true
		if !image {
			a.ImageURL = ""
		}
		a.Layout = Layout{}
		return *a
	}

	if size >= 0 {
		return e.GetArticle(size-100, image)
	}
	return Article{Title: ""}
}

func NewEdition(ctx context.Context, now time.Time, sources []Source) (*Edition, error) {
	morning := now.Truncate(24 * time.Hour).Add(morningEdition)
	evening := now.Truncate(24 * time.Hour).Add(eveningEdition)

	catMap := make(map[string]struct{})
	for _, s := range sources {
		for _, c := range s.Categories {
			catMap[c] = struct{}{}
		}
	}
	cats := make([]string, 0, len(catMap))
	for c := range catMap {
		cats = append(cats, c)
	}

	e := Edition{
		ID:         idgen.New("edt"),
		Sources:    sources,
		Categories: cats,
		Created:    time.Now(),
	}

	e.Date = time.Now().Format("Monday January 02 2006")

	switch {
	case now.After(morning) && now.Before(evening):
		e.StartTime = morning
		e.EndTime = evening
		e.Name = "Morning Edition"
	case now.Before(morning) || now.After(evening):
		e.StartTime = evening
		e.EndTime = morning.Add(24 * time.Hour)
		e.Name = "Evening Edition"
	}

	return &e, nil
}
