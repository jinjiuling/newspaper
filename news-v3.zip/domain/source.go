package domain

type Source struct {
	ID           int
	Name         string
	URL          string
	FeedURL      string
	Categories   []string
	ImageHeaders map[string]string // Custom HTTP headers for image fetching (e.g. Referer)
	ForceFetch   bool
	DisableFetch bool
	Enabled      bool
}
